import React from 'react'

export default function VdmtHome() {
  return (
    <div className='alert alert-suscess'>
        <h4>Mã sinh viên : 2310900099</h4>
        <h4>Họ tên : Vũ Đỗ Minh Thành</h4>
        <h4>Lớp : K23CNT3</h4>
        <h4>Email : tawoz131105@gmail.com</h4>
    </div>
  )
}
